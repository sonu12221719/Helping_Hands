<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$date = $_POST['date'];
$complaint_type = $_POST['complaint_type'];
$explain = $_POST['explain'];
$file = $_POST['file']

$email_form = 'sgh@gmail.com';

$email_subject = 'New Form Submission';

$email_body = "First Name: $fname.\n".
              "Last Name: $lname.\n".
              "Phone: $phone.\n".
              "Email: $email.\n".
              "Date: $date.\n".
              "Complaint Type: $Complaint_type.\n".
              "Explain: $explain.\n".
              "Proof: $file.\n";
$to = 'sonukumar200219@gmail.com';

$headers = "From: $email_form\r\n";

$headers = "Reply-To: $email\r\n";

mail($to,$email_subject,$email_body,$headers);

header("Location: Helping_Hands.html")

?>