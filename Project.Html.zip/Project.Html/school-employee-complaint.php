<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$phone = $_POST['phone'];
$department = $_POST['department'];
$supervisor_name = $_POST['supervisor-name'];
$date = $_POST['date'];
$time = $_POST['time'];
$location = $_POST['location']
$explain = $_POST['explain']

$email_form = 'sgh@gmail.com';

$email_subject = 'New Form Submission';

$email_body = "First Name: $fname.\n".
              "Last Name: $lname.\n".
              "Phone: $phone.\n".
              "Department: $department.\n".
              "Supervisor Name: $supervisor_name.\n".
              "Date: $date.\n".
              "Time: $time.\n".
              "Location of Incident: $location.\n";
              "About Complaint: $eplain"
$to = 'sonukumar200219@gmail.com';

$headers = "From: $email_form\r\n";

$headers = "Reply-To: $email\r\n";

mail($to,$email_subject,$email_body,$headers);

header("Location: Helping_Hands.html")

?>