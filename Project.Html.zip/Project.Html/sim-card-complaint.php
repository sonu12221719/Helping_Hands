<?php
$name = $_POST['name'];
$sim = $_POST['sim'];
$address = $_POST['address'];
$customer_number = $_POST['customer-number'];
$phone = $_POST['phone'];
$explain = $_POST['explain']

$email_form = 'sgh@gmail.com';

$email_subject = 'New Form Submission';

$email_body = "Customer Name: $fname.\n".
              "Sim-Card: $sim.\n".
              "Address: $address.\n".
              "Customer Number: $customer_number.\n".
              "Sim Number: $phone.\n".
              "About Complaint: $explain"
$to = 'sonukumar200219@gmail.com';

$headers = "From: $email_form\r\n";

$headers = "Reply-To: $email\r\n";

mail($to,$email_subject,$email_body,$headers);

header("Location: Helping_Hands.html")

?>